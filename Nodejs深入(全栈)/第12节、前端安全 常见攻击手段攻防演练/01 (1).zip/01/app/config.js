modeule.export = {
    user: "root",
    password: 'example',
    database: 'test',
    host: 'localhost',
    port: 3306

}