module.exports = [{
    question: '问题一：函数的扩展中，关于rest参数的描述，正确的是',
    result: '',
    answer: 0,
    options: [
      'A、获取函数剩下部分的参数',
      'B、rest参数不可以是函数的最后一个参数',
      'C、获取函数的第一个参数',
      'D、一个名叫rest的参数'
    ]
  },
  {
    question: '问题二：关于Symbol，错误的说法是',
    result: '',
    answer: 2,
    options: [
      'A、是ES6新增的一种数据类型',
      'B、Symbol() === Symbol() 结果为false',
      `C、Symbol('same') === Symbol('same') 结果为true`,
      'D、当symbol值作为对象的属性名的时候，不能用点运算符获取对应的值。'
    ]
  },
  {
    question: '问题三：关于Symbol，错误的说法是',
    result: '',
    answer: 3,
    options: [
      'A、是ES6新增的一种数据类型',
      'B、Symbol() === Symbol() 结果为false',
      `C、Symbol('same') === Symbol('same') 结果为true`,
      'D、当symbol值作为对象的属性名的时候，不能用点运算符获取对应的值。'
    ]
  }

]