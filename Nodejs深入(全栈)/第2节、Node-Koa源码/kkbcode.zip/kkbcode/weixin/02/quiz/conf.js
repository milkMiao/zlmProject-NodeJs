module.exports = {
    appid: 'wxfc60e88fa8622c69',
    appsecret: '23c57e17b4073db7d03cca2ebac525ae',
    token: 'kaikeba',
    port: 3000,
    // 可选，默认为true。由于微信公众平台接口调试工具在明文模式下不发送签名，所以如要使用该测试工具，请将其设置为false
    checkSignature: false ,
    baseUrl:'http://josephxia.free.idcfengye.com',
};