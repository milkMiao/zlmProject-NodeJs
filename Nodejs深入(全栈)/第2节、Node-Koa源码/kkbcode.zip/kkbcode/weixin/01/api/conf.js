module.exports = {
    appid:'wxfc60e88fa8622c69',
    appsecret:'23c57e17b4073db7d03cca2ebac525ae',
    token:'kaikeba'
}