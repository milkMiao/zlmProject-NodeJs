# 课程代码分享 （仅供参考）



# 基础知识

- [掘金个人首页](https://juejin.im/user/1978776660216136/posts)
    
- 掘金 (整理不易 喜欢的点赞 关注)
    - [Git学习笔记](https://juejin.im/post/5eba6146e51d454dca710e73)
    - [Jest入门](https://juejin.im/post/5e6388366fb9a07cda097c47#heading-30)
    - [Linux入门](https://juejin.im/post/5e12f6616fb9a047fa032cc2)
    - [数据库连接池](https://juejin.im/post/5e50ebade51d4526f23a1c10)
    - [装饰器是什么](https://juejin.im/post/5de47ef851882548393c37be)
    - [浏览器缓存](https://juejin.im/post/5e8c1f04f265da480836ada5)

[个人网页](https://www.josephxia.com)



## 示例代码运行
- NodeJS 10.0 need https://nodejs.org/en/
- Clone or download this repository
Enter your local directory, and 
- install dependencies:
``` bash
npm install
```