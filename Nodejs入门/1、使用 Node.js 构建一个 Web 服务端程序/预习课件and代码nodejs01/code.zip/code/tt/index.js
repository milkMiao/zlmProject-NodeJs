// console.log(aa);
// console.log(module.exports)
// // module.exports = {
// //     name:"张三"
// // }
// let a = 10;
// var b = 20;
// console.log(global.a);
// console.log(this.a);
// (function(){
//     var a = 10;
// // })()
// console.log(a);
// console.time("start");
// for(let i =0;i<100;i++){  
// }

// console.timeEnd("start");
// process.env.NODE_ENV = "dev";
// console.log(process.env.NODE_ENV)

// process.nextTick(function(){
//     console.log(this==process)
// })

// setImmediate(function(){
//     console.log("setImmediate");
// })
// console.log(222);
// setTimeout(() => {
//     console.log("timeout");
// },2);
// console.log(this===exports)

// let reg = /^[1-9]\.?\d*$/g;
// let reg = /(^[1-9]\d*$)|(^[1-9]+\.\d{2}$)/g;
// // let reg = /^[1-9]/;
// let r = reg.test("12.21");
// console.log(r)