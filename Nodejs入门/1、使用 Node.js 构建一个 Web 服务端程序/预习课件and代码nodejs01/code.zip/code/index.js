// AMD sea.js  CMD require.js
// console.log("我是index.js");
// let Ma = require("./Ma");
// // console.log(a);
// console.log(Ma.a)
// let cai = new Ma.Person();
// cai.hobby();
// require("./home");
// node_modules里的模块;
// let {a,b} = require("mytest");
// console.log(a);
// b();
// require("mytest")
// const http = require("http");
// npm:包管理器
// dependencies:运行依赖jquery、vue、react  ；devDependencies：开发依赖 sass less；

