console.log("我是index.js");
require("./a");
require("./b");