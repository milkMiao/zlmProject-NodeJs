console.log("我是a.js")
require("test");